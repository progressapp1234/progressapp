package com.example.progress;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class settingspage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settingspage);
    }

    public void aboutyou(View view) {
        Intent about = new Intent(this, aboutyou.class);
        startActivity(about);// starts the about you page
        //test if firebase is working
        //  Toast.makeText( MainActivity.this, "Firebase connection successful",Toast.LENGTH_LONG).show();

    }

    public void accessibility(View view) {
        Intent accessibility = new Intent(this, accessibility.class);
        startActivity(accessibility);// starts the accessibility page

    }

    public void aboutourapp(View view) {
        Intent aboutourapp = new Intent(this, aboutourapp.class);
        startActivity(aboutourapp);// starts the about our app page

    }

    public void helppage(View view) {
        Intent helppage = new Intent(this, helppage.class);
        startActivity(helppage);// starts the help page

    }

}