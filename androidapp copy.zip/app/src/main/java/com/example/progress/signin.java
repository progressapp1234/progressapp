package com.example.progress;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class signin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);
    }

    public void signin(View view) {
        Intent signin = new Intent(this, signin.class);
        startActivity(signin);// starts the setup page
        //test if firebase is working


    }

    public void createaccount(View view) {
        Intent createaccount = new Intent(this, createaccount.class);
        startActivity(createaccount);// starts the setup page
        //test if firebase is working
        // Toast.makeText(mainactivity.this, "Firebase connection successful", Toast.LENGTH_LONG).show();

    }
}