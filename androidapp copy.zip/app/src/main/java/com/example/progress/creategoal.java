package com.example.progress;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ToggleButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class creategoal extends AppCompatActivity {

       /* Notes for creating a tracker class goals
       - create - done + passed testing
       - write - done + passed testing
       - duplicates - done + one bug
       For next stage dashboard:
       - update - done + passed testing
       - delete - done + passed testing
       - sort - incomplete + bugs
       - goal list - incomplete + bugs


*/

    /* VARIABLES
     */

    private Tracker t;

// .....................................................................


    /* METHODS
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.creategoal);
    }

    public void settingspage(View view) {
        Intent settings = new Intent(this, settingspage.class);
        startActivity(settings);
    }

    public void createTracker(View view) {
        /* 1. disable create button log debug message.
           2. declare and assign form input to local variables.
           3. uses those variables to create a new tracker object.
         */

        view.setEnabled(false);
        Log.d("CREATE", "BUTTON WORKS");

        String trackingName;
        String trackingCategory;
        String trackingObjective;
        int trackingDailyTarget;
        String trackingNotifications;
        String trackingUnit;
        // String trackingColour;
        // String trackingPeriod; //convert to int
        // String trackingDays;


        trackingName = ((EditText) findViewById(R.id.trackingName)).getText().toString();
        trackingCategory = ((ToggleButton) findViewById(R.id.trackingCategory)).getText().toString();
        trackingObjective = ((ToggleButton) findViewById(R.id.trackingObjective)).getText().toString();
        trackingDailyTarget = Integer.parseInt(((EditText) findViewById(R.id.trakingDailyTarget)).getText().toString());
        trackingNotifications = ((ToggleButton) findViewById(R.id.trackingNotifications)).getText().toString();
        trackingUnit = ((EditText) findViewById(R.id.trackingUnit)).getText().toString();

        Tracker t = new Tracker(trackingName,trackingCategory,trackingObjective,trackingDailyTarget, trackingNotifications, trackingUnit);

        /* 4. check for trackers with the same name already in the database.
           5. only create trackers with unique name.
         */

        boolean[] duplicate = checkDatabaseDuplicates(t);
        boolean val = duplicate[0];

        System.out.println(val);

        if(val == true){
            System.out.println("You cannot create this tracker");
            Log.d("CREATE", "Failed");
        }else if(val == false){
            writeToDatabase(t);
            System.out.println("Tracker created.");
            Log.d("CREATE", "Successful");
        }else{
            System.out.println("Tracker created.");
            Log.d("CREATE", "Error");
        }

    }

    public void writeToDatabase(Tracker t){
        /* 1. create a database instance.
           2. write the new tracker to the database.
         */
        DatabaseReference mDatabase;

        mDatabase = FirebaseDatabase.getInstance().getReference();

        mDatabase.child("trackers-test-1").child(t.trackingName).setValue(t);

    }

    public boolean[] checkDatabaseDuplicates(Tracker t){
        /* 1. create a database instance.
           2. check if the tracker is found in the database using value event listener.
            - value event listener methods onDataChange and onCancelled go hand in hand.
           3. depending on if or not a tracker with the same name already exists,
              return the outcome.
         */

        DatabaseReference mDatabase;

        mDatabase = FirebaseDatabase.getInstance().getReference();

        boolean[] duplicate = new boolean[1];

        mDatabase.child("trackers-test-1").child(t.trackingName).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    // System.out.println("A tracker by this name already exists.");
                    duplicate[0] = false;
                } else {

                    // writeToDatabase(t);
                    // System.out.println("The will be been created.");
                    duplicate[0] = true;
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }

        });

        return duplicate;

    }






}
