package com.example.progress;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;

import androidx.appcompat.app.AppCompatActivity;

public class Tracker {


    //TRACKER VARIABLES

    //Tracker identification information - name, category (habit or goal) and objective (make or break).
    String trackingName;
    String trackingCategory;
    String trackingObjective;

    //Tracker tracking information - mainly used in logic of visualisations + prompts for input.
    int trackingPeriod;
    String trackingDays;
    int trackingDailyTarget;
    String trackingNotifications;

    //Tracker stylistic information- to be used for progress bar customisation.
    String trackingUnit;
    String trackingColour;

    //......................................................

    //TRACKER CONSTRUCTORS
    //only current working tracker.

    public Tracker(String trackingName, String trackingCategory, String trackingObjective, int trackingDailyTarget, String trackingNotifications, String trackingUnit){
        this.trackingName = trackingName;
        this.trackingCategory = trackingCategory;
        this.trackingObjective = trackingObjective;
        this.trackingDailyTarget = trackingDailyTarget;
        this.trackingNotifications = trackingNotifications;
        this.trackingUnit = trackingUnit;

    }

    //........................................................

    //TRACKER GETTERS AND SETTERS
    public String getTrackingName() {
        return trackingName;
    }

    public void setTrackingName(String trackingName) {
        this.trackingName = trackingName;
    }

    public String getTrackingCategory() {
        return trackingCategory;
    }

    public void setTrackingCategory(String trackingCategory) {
        this.trackingCategory = trackingCategory;
    }

    public String getTrackingObjective() {
        return trackingObjective;
    }

    public void setTrackingObjective(String trackingObjective) {
        this.trackingObjective = trackingObjective;
    }

    public int getTrackingPeriod() {
        return trackingPeriod;
    }

    public void setTrackingPeriod(int trackingPeriod) {
        this.trackingPeriod = trackingPeriod;
    }

    public String getTrackingDays() {
        return trackingDays;
    }

    public void setTrackingDays(String trackingDays) {
        this.trackingDays = trackingDays;
    }

    public int getTrackingDailyTarget() {
        return trackingDailyTarget;
    }

    public void setTrackingDailyTarget(int trackingDailyTarget) {
        this.trackingDailyTarget = trackingDailyTarget;
    }

    public String getTrackingNotifications() {
        return trackingNotifications;
    }

    public void setTrackingNotifications(String trackingNotifications) {
        this.trackingNotifications = trackingNotifications;
    }

    public String getTrackingUnit() {
        return trackingUnit;
    }

    public void setTrackingUnit(String trackingUnit) {
        this.trackingUnit = trackingUnit;
    }

    public String getTrackingColour() {
        return trackingColour;
    }

    public void setTrackingColour(String trackingColour) {
        this.trackingColour = trackingColour;
    }
}

