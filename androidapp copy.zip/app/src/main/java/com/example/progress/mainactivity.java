package com.example.progress;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class mainactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);
    }

    public void creategoal(View view) {
        Intent creategoal = new Intent(this, creategoal.class);
        startActivity(creategoal);// starts the setup page
        //test if firebase is working
        Toast.makeText( mainactivity.this, "Firebase connection successful",Toast.LENGTH_LONG).show();

    }


    public void settingspage(View view) {
        Intent settings = new Intent(this, settingspage.class);
        startActivity(settings);
    }


}
